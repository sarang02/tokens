# `@solana/wallet-adapter-particle`

<!-- @TODO -->

Coming soon.