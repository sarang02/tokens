# @solana/wallet-adapter-unsafe-burner

## 0.1.7

### Patch Changes

-   a3d35a1: Add `signIn` (Sign In With Solana) method
-   Updated dependencies [a3d35a1]
    -   @solana/wallet-adapter-base@0.9.23

## 0.1.6

### Patch Changes

-   8a8fdc72: Update dependencies
-   Updated dependencies [8a8fdc72]
    -   @solana/wallet-adapter-base@0.9.22

## 0.1.5

### Patch Changes

-   Updated dependencies [f99c2154]
    -   @solana/wallet-adapter-base@0.9.21

## 0.1.4

### Patch Changes

-   Updated dependencies [912cc0e]
    -   @solana/wallet-adapter-base@0.9.20

## 0.1.3

### Patch Changes

-   353f2a5: Add isVersionedTransaction helper function
-   Updated dependencies [353f2a5]
    -   @solana/wallet-adapter-base@0.9.19
