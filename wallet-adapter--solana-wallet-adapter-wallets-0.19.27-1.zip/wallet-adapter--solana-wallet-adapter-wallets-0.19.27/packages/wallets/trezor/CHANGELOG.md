# @solana/wallet-adapter-trezor

## 0.1.0

### Minor Changes

-   a9f41dde: Release Trezor adapter
