# `@solana/wallet-adapter-trezor`

<!-- @TODO -->

Coming soon.
