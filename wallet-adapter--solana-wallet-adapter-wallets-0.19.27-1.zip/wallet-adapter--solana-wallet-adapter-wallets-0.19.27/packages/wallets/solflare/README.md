# `@solana/wallet-adapter-solflare`

<!-- @TODO -->

Coming soon.
