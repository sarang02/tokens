# `@solana/wallet-adapter-trust`

<!-- @TODO -->

Coming soon.