# @solana/wallet-adapter-base-ui

## 0.1.2

### Patch Changes

-   Updated dependencies [bdc0eff]
    -   @solana/wallet-adapter-react@0.15.35

## 0.1.1

### Patch Changes

-   Updated dependencies [a3d35a1]
    -   @solana/wallet-adapter-react@0.15.34

## 0.1.0

### Minor Changes

-   7b06737: Add base-ui package with wallet button hooks

### Patch Changes

-   Updated dependencies [7b06737]
-   Updated dependencies [ba57f75]
-   Updated dependencies [7c6f2e1]
    -   @solana/wallet-adapter-react@0.15.33
