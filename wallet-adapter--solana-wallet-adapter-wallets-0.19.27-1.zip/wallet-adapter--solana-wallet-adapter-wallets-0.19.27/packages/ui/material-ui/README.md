# `@solana/wallet-adapter-material-ui`

<!-- @TODO -->

Coming soon.