# Example projects

Please note that the starter/example projects here are primarily for testing in-development versions of wallet-adapter. While some components/code may be useful, they cannot be copy-pasted and used to start building a new dapp as-is.

The recommended way to create a new Solana dapp is using [create-solana-dapp](https://github.com/solana-developers/create-solana-dapp). All frontend templates include wallet-adapter support. 