# `@solana/wallet-adapter-bitpie`

<!-- @TODO -->

Coming soon.
