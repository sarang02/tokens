# `@solana/wallet-adapter-tokenary`

<!-- @TODO -->

Coming soon.