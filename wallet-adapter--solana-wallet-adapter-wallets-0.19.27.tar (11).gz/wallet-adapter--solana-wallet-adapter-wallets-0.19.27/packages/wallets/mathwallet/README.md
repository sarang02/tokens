# `@solana/wallet-adapter-mathwallet`

<!-- @TODO -->

Coming soon.