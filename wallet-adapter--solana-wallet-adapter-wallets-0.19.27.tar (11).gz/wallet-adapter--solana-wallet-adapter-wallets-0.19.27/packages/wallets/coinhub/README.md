# `@solana/wallet-adapter-coinhub`

<!-- @TODO -->

Coming soon.
