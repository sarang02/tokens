# @solana/wallet-adapter-walletconnect

## 0.1.16

### Patch Changes

-   Updated dependencies [a3d35a1]
    -   @solana/wallet-adapter-base@0.9.23

## 0.1.15

### Patch Changes

-   18e023f: Add support for versioned transactions

## 0.1.14

### Patch Changes

-   8a8fdc72: Update dependencies
-   Updated dependencies [8a8fdc72]
    -   @solana/wallet-adapter-base@0.9.22

## 0.1.13

### Patch Changes

-   61e86b58: Taking a new version of `@jnwng/walletconnect-solana` with upgraded dependencies on `@walletconnect/sign-client`

## 0.1.12

### Patch Changes

-   f5abf15c: Using WalletConnect (alone, or through `@solana/wallet-adapter-wallets` no longer fatals in Next 13.

## 0.1.11

### Patch Changes

-   Updated dependencies [f99c2154]
    -   @solana/wallet-adapter-base@0.9.21

## 0.1.10

### Patch Changes

-   Updated dependencies [912cc0e]
    -   @solana/wallet-adapter-base@0.9.20

## 0.1.9

### Patch Changes

-   Updated dependencies [353f2a5]
    -   @solana/wallet-adapter-base@0.9.19
