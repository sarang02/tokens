# `@solana/wallet-adapter-fractal`

This package provides an adapter to enable Solana apps to connect to a Fractal Wallet.

For quick setup, please refer to the solana-labs/wallet-adapter [README](https://github.com/solana-labs/wallet-adapter#quick-setup-using-react-ui)

Integrating with [Fractal's Developer APIs and SDKs](https://developers.fractal.is) is the easiest way to build web3 games.
