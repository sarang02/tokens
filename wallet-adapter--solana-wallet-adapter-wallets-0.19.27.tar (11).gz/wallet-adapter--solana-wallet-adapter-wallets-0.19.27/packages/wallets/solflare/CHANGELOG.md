# @solana/wallet-adapter-solflare

## 0.6.28

### Patch Changes

-   3d2e0cd5: Optimize Solflare MetaMask snap detection

## 0.6.27

### Patch Changes

-   a4566f89: Add Solflare MetaMask Snap support

## 0.6.26

### Patch Changes

-   Updated dependencies [a3d35a1]
    -   @solana/wallet-adapter-base@0.9.23

## 0.6.25

### Patch Changes

-   e5024dc: Support `signAndSendTransaction` method in Solflare adapter

## 0.6.24

### Patch Changes

-   8a8fdc72: Update dependencies
-   Updated dependencies [8a8fdc72]
    -   @solana/wallet-adapter-base@0.9.22

## 0.6.23

### Patch Changes

-   Updated dependencies [f99c2154]
    -   @solana/wallet-adapter-base@0.9.21

## 0.6.22

### Patch Changes

-   b4558126: Add support for redirecting to Solflare browser on iOS

## 0.6.21

### Patch Changes

-   21d2c863: Add support for `accountChanged` event to Solflare adapter

## 0.6.20

### Patch Changes

-   Updated dependencies [912cc0e]
    -   @solana/wallet-adapter-base@0.9.20

## 0.6.19

### Patch Changes

-   Updated dependencies [353f2a5]
    -   @solana/wallet-adapter-base@0.9.19
