# `@solana/wallet-adapter-safepal`

<!-- @TODO -->

Coming soon.