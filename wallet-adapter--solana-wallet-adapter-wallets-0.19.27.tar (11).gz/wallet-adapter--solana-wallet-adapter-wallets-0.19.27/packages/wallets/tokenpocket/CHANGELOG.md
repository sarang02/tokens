# @solana/wallet-adapter-tokenpocket

## 0.4.19

### Patch Changes

-   Updated dependencies [a3d35a1]
    -   @solana/wallet-adapter-base@0.9.23

## 0.4.18

### Patch Changes

-   8a8fdc72: Update dependencies
-   Updated dependencies [8a8fdc72]
    -   @solana/wallet-adapter-base@0.9.22

## 0.4.17

### Patch Changes

-   Updated dependencies [f99c2154]
    -   @solana/wallet-adapter-base@0.9.21

## 0.4.16

### Patch Changes

-   Updated dependencies [912cc0e]
    -   @solana/wallet-adapter-base@0.9.20

## 0.4.15

### Patch Changes

-   Updated dependencies [353f2a5]
    -   @solana/wallet-adapter-base@0.9.19
