# @solana/wallet-adapter-particle

## 0.1.12

### Patch Changes

-   bef1cad: Update Particle adapter dependency

## 0.1.11

### Patch Changes

-   7d41f2fe: Update Particle adapter

## 0.1.10

### Patch Changes

-   Updated dependencies [a3d35a1]
    -   @solana/wallet-adapter-base@0.9.23

## 0.1.9

### Patch Changes

-   8a8fdc72: Update dependencies
-   Updated dependencies [8a8fdc72]
    -   @solana/wallet-adapter-base@0.9.22

## 0.1.8

### Patch Changes

-   Updated dependencies [f99c2154]
    -   @solana/wallet-adapter-base@0.9.21

## 0.1.7

### Patch Changes

-   Updated dependencies [912cc0e]
    -   @solana/wallet-adapter-base@0.9.20

## 0.1.6

### Patch Changes

-   Updated dependencies [353f2a5]
    -   @solana/wallet-adapter-base@0.9.19
